import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
public class user_Interface {
}
class get_ues {
    public int numDistinct(String s, String t) {
        if(t.length()==0 || s.length()==0) return 0;
        int slen=s.length(),tlen=t.length();
        int[][] dp=new int[tlen][slen];
        int i,j;
        if(s.charAt(slen-1)==t.charAt(tlen-1)) dp[tlen-1][slen-1]=1;
        for(i=slen-2;i>=0;i--){
            if(t.charAt(tlen-1)==s.charAt(i)) dp[tlen-1][i]=dp[tlen-1][i+1]+1;
            else dp[tlen-1][i]=dp[tlen-1][i+1];
        }
        int c=2;
        for(i=tlen-2;i>=0;i--){
            for(j=slen-c;j>=0;j--){
                if(t.charAt(i)==s.charAt(j)) dp[i][j]=dp[i][j+1]+dp[i+1][j+1];
                else dp[i][j]=dp[i][j+1];
            }
            c++;
        }
        return dp[0][0];
    }
}