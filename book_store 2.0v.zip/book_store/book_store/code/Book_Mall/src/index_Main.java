import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.sql.*;
import javax.swing.ImageIcon;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
class main {
	Map<String,Boolean> map = new HashMap<String,Boolean>();
	public boolean isMatch(String s, String p) {
		int sl = s.length();
		int pl = p.length();

		if(pl==0&&sl!=0)return false;
		if(pl==0&&sl==0)return true;

		StringBuffer sb = new StringBuffer();
		sb.append(p.charAt(0));
		int count=p.charAt(0)=='*'?1:0;
		for(int i=1; i<pl;i++){
			if(p.charAt(i)==p.charAt(i-1)&&(p.charAt(i)=='*')){
				count++;
				continue;
			}else if(p.charAt(i)=='*'){
				count++;
			}
			sb.append(p.charAt(i));
		}
		p = sb.toString();


		if(sl<pl-count)return false;

		return mm(s,p);
	}
	private boolean mm(String s,String p){
		if(map.get(s+"-"+p)!=null)return map.get(s+"-"+p);
		int sl = s.length();
		int pl = p.length();
		if(pl==0&&sl!=0)return Boolean.FALSE;
		if(pl==0&&sl==0)return true;
		if(sl==0&&pl!=0){
			if(pl==1&&p.charAt(0)=='*'){
				return true;
			}else{
				map.put(s+"-"+p,Boolean.FALSE);
				return Boolean.FALSE;
			}
		}
		//both !=0
		if(p.charAt(0)=='?'||p.charAt(0)==s.charAt(0)){
			boolean bb =  mm(s.substring(1,sl),p.substring(1,pl));
			map.put(s+"-"+p,bb);
			return bb;
		}else if(p.charAt(0)=='*'){
			boolean bb =  mm(s,p.substring(1,pl))||mm(s.substring(1,sl),p.substring(1,pl))||mm(s.substring(1,sl),p);
			map.put(s+"-"+p,bb);
			return bb;
		}else{
			map.put(s+"-"+p,Boolean.FALSE);
			return Boolean.FALSE;
		}

	}
}
class stor {
	public int numDistinct(String s, String t) {
		if(t.length()==0 || s.length()==0) return 0;
		int slen=s.length(),tlen=t.length();
		int[][] dp=new int[tlen][slen];
		int i,j;
		if(s.charAt(slen-1)==t.charAt(tlen-1)) dp[tlen-1][slen-1]=1;
		for(i=slen-2;i>=0;i--){
			if(t.charAt(tlen-1)==s.charAt(i)) dp[tlen-1][i]=dp[tlen-1][i+1]+1;
			else dp[tlen-1][i]=dp[tlen-1][i+1];
		}
		int c=2;
		for(i=tlen-2;i>=0;i--){
			for(j=slen-c;j>=0;j--){
				if(t.charAt(i)==s.charAt(j)) dp[i][j]=dp[i][j+1]+dp[i+1][j+1];
				else dp[i][j]=dp[i][j+1];
			}
			c++;
		}
		return dp[0][0];
	}
}

class user {
	public int numDistinct(String s, String t) {
		if(t.length()==0 || s.length()==0) return 0;
		int slen=s.length(),tlen=t.length();
		int[][] dp=new int[tlen][slen];
		int i,j;
		if(s.charAt(slen-1)==t.charAt(tlen-1)) dp[tlen-1][slen-1]=1;
		for(i=slen-2;i>=0;i--){
			if(t.charAt(tlen-1)==s.charAt(i)) dp[tlen-1][i]=dp[tlen-1][i+1]+1;
			else dp[tlen-1][i]=dp[tlen-1][i+1];
		}
		int c=2;
		for(i=tlen-2;i>=0;i--){
			for(j=slen-c;j>=0;j--){
				if(t.charAt(i)==s.charAt(j)) dp[i][j]=dp[i][j+1]+dp[i+1][j+1];
				else dp[i][j]=dp[i][j+1];
			}
			c++;
		}
		return dp[0][0];
	}
}



public class index_Main implements ActionListener{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JFrame first;
	private JFrame signIn;
	private JFrame createA;
	private mall_Interface store;
	private ImageIcon background;
	private JPanel imagePanel;
	private JFrame frame = new JFrame("Background testing");
	/**
	 * Main View Constructor
	 * @param vis
	 */





	public index_Main(boolean vis) {
		first = new JFrame("Online Bookstore");
		first.setLayout(new BorderLayout());
		first.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		background = new ImageIcon("003.jpg");// background photo
		JLabel label = new JLabel(background);//put photo in the label
		//set it to fill out
		label.setBounds(0, 0, background.getIconWidth(),background.getIconHeight());
		// Transfer the Pane to JPanel，if not i can not use setOpaque() to transparentizing.
		imagePanel = (JPanel) first.getContentPane();
		imagePanel.setOpaque(false);
		// Default layout manager for the content pane isBorderLayout
		imagePanel.setLayout(new FlowLayout());
//		imagePanel.add(new JButton("test button"));

		first.getLayeredPane().setLayout(null);
		// set the picture to the base.
		first.getLayeredPane().add(label, new Integer(Integer.MIN_VALUE));
		first.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		first.setSize(background.getIconWidth(), background.getIconHeight());
		first.setResizable(false);
		first.setVisible(true);




		JPanel greeting = new JPanel(new GridLayout(5, 4));
		
		JPanel welcome = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JLabel w = new JLabel("This is the online bookstore!");
		w.setFont(new Font("Times New Roman", Font.PLAIN, 30));

		welcome.add(w);
		
		greeting.add(welcome);


		
		JButton create = new JButton("Register");
		create.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		create.addActionListener(this);
		create.setOpaque(false);
		create.setBackground(new Color(2,2,2));
//		create.setBackground(c);
//		create.setOpaque(false); //transparentizing/*****************************************************/ImageIcon icon = new ImageIcon("images/insert.jpg");submitButton.setIcon(icon);


		JPanel choice = new JPanel(new FlowLayout());
		JButton sIn = new JButton("Login");
		sIn.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		sIn.addActionListener(this);

		JButton guest = new JButton("Guest");
		guest.setFont(new Font("Times New Roman", Font.PLAIN, 20));
		guest.addActionListener(this);

		greeting.add(guest);
		greeting.add(sIn);
		greeting.add(create);
		
		//greeting.add(choice);
		
		first.add(greeting, BorderLayout.CENTER);
		first.pack();
		first.setVisible(vis);
	}
	/**
	 * Login Frame
	 */

	class books {
		public int numDistinct(String s, String t) {
			if ("".equals(s) && "".equals(t)) {
				return 1;
			} else if ("".equals(s)) {
				return 0;
			} else if ("".equals(t)) {
				return 1;
			}
			/**

			 *
			 * }
			 */
			int[][] dp = new int[t.length()][s.length()];
			for (int i = 0; i < t.length(); i++) {
				for (int j = 0; j < s.length(); j++) {
					if (t.charAt(i) == s.charAt(j)) {
						if (i == 0 && j == 0) {
							dp[i][j] = 1;
						} else if (i > 0 && j > 0) {
							dp[i][j] = dp[i - 1][j - 1] + dp[i][j - 1];
						} else if (i == 0 && j > 0) {
							dp[i][j] = dp[i][j - 1] + 1;
						} else if (i > 0 && j == 0) {
							dp[i][j] = 0;
						}
					} else {
						if (j > 0) {
							dp[i][j] = dp[i][j - 1];
						}
					}
				}
			}
			return dp[t.length() - 1][s.length() - 1];
		}
	}


	public void signIn() {
		signIn = new JFrame("Login");
		signIn.setLayout(new BorderLayout());
		
		JPanel cred = new JPanel(new GridLayout(3,1));
		
		JPanel i = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JLabel info = new JLabel("Please enter your login information!");
		info.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		i.add(info);
		
		JPanel eInput = new JPanel(new FlowLayout());
		JTextField em = new JTextField(40);
		em.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		JLabel email = new JLabel("Email");
		email.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		eInput.add(email);
		eInput.add(em);
		
		JPanel pInput = new JPanel(new FlowLayout());
		JTextField p = new JTextField(20);
		p.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		JLabel pW = new JLabel("Password");
		pW.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		pInput.add(pW);
		pInput.add(p);
		
		JPanel sBut = new JPanel(new FlowLayout());
		JButton signBut = new JButton("Login");
		signBut.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		signBut.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String eIn = "'" + em.getText() + "'";
				String pIn = p.getText();
				String query = "select name from customer where email = " + eIn + "and password = " + "'" + pIn + "'";
				ResultSet result;
				String name;
				try(Connection c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bookstore", "postgres", "123456"); Statement s = c.createStatement();){
					result = s.executeQuery(query);
					if(result.next()) {
						name = result.getString("name");
						first.dispose();
						signIn.dispose();
						store = new mall_Interface(true, name);
						
					}
					else {
						JOptionPane.showMessageDialog(new JFrame(), "Incorrect email or password");
					}
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			}
			
		});
		sBut.add(signBut);
		
		cred.add(i);
		cred.add(eInput);
		cred.add(pInput);
		
		signIn.add(cred, BorderLayout.CENTER);
		signIn.add(sBut, BorderLayout.SOUTH);
		signIn.pack();
		signIn.setVisible(true);
		
	}

	class guest {
		public double findMedianSortedArrays(int[] nums1, int[] nums2) {
			int len1=nums1.length;
			int len2=nums2.length;

			int flag=(len1+len2)%2;
			int aim=flag==0?((len1+len2)/2-1):(len1+len2)/2;

			int count=0;
			int k;

			int lb1=0,ub1=nums1.length-1;

			int lb2=0,ub2=nums2.length-1;
			if(len1==0||len2==0){
				if (len1==0) {
					if(len2==1) return nums2[0];
					else return getMedian(aim, nums2, flag);
				}
				else {
					if(len1==1) return nums1[0];
					else return getMedian(aim,nums1,flag);
				}
			}
			while (count!=aim){
				k=aim-count>1?(int)Math.floor((aim-count)/2.0):1;
				if(ub1<lb1||ub2<lb2){
					if(ub1<lb1){
						lb2+=aim-count;
						return getMedian(lb2,nums2,flag);
					}
					if(ub2<lb2){

						lb1+=aim-count;
						return getMedian(lb1,nums1,flag);
					}
				}else {
					if (k > ub1 - lb1 + 1||k > ub2 - lb2 + 1) {
						if (k > ub1 - lb1 + 1) {
							if (nums2[lb2+k - 1] > nums1[ub1]) {
								count+=ub1 - lb1 + 1;
								lb1 += ub1 + 1;
							} else {
								lb2 += k;
								count += k;
							}

						} else if (k > ub2 - lb2 + 1) {
							if (nums1[lb1+k - 1] > nums2[ub2]) {
								count+=ub2 - lb2 + 1;
								lb2 += ub2 + 1;
							} else {
								lb1 += k;
								count += k;
							}
						}
					} else {
						if (nums1[lb1+k-1]>nums2[lb2+k-1]) {
							lb2 += k;
						}else {
							lb1+=k;
						}
						count += k;
					}
				}
			}
			if(ub1<lb1) {
				if (lb2==ub2) {
					return (double)nums2[lb2];
				}else{
					return getMedian(0, new int[]{nums2[lb2], nums2[lb2 + 1]}, flag);
				}
			} else if (ub2<lb2) {
				if (lb1==ub1) {
					return (double)nums1[lb1];
				}else{
					return getMedian(0,new int[]{nums1[lb1],nums1[lb1+1]},flag);
				}
			}else {
				int min1,min2=0;
				min1=Math.min(nums1[lb1], nums2[lb2]);
				if(min1==nums1[lb1]){
					if (ub1+1-lb1>1){
						min2=Math.min(nums1[lb1+1],nums2[lb2]);
					}
					if (ub1+1-lb1<=1){
						min2=nums2[lb2];
					}

				}else {
					if (ub2+1-lb2>1){
						min2=Math.min(nums2[lb2+1],nums1[lb1]);
					}
					if (ub2+1-lb2<=1){
						min2=nums1[lb1];
					}
				}
				return getMedian(0, new int[]{min1,min2}, flag);
			}
		}


		public  double getMedian(int lb,int[] nums,int isOdd){
			if(isOdd==1){
				return Math.min(nums[lb],nums[lb+1]);
			}else return (nums[lb]+nums[lb+1])/2.0;
		}
	}
	class storelogin {
		public boolean isMatch(String s, String p) {
			int n = s.length();
			int m = p.length();
			boolean[][] dp = new boolean[n + 1][m + 1];
			dp[0][0] = true;

			for (int i = 1; i <= m; i ++) {
				if (p.charAt(i - 1) == '*') {
					dp[0][i] = true;
				} else {
					break;
				}
			}

			for (int i = 1; i <= n; i ++) {
				for (int j = 1; j <= m; j ++) {
					if (p.charAt(j - 1) == '*') {
						dp[i][j] = dp[i - 1][j] || dp[i][j - 1];
					} else {
						dp[i][j] = dp[i - 1][j - 1] && (p.charAt(j - 1) == s.charAt(i - 1) || p.charAt(j - 1) == '?');
					}
				}
			}
			return dp[n][m];
		}
	}

	class regester {
		public int numDistinct(String s, String t) {
			if (s.length() == 0) {
				return 0;
			}
			if (t.length() == 0) {
				return 1;
			}
			int len = s.length();
			int len1 = t.length();
			int[][] dp = new int[len1][len];

			if (s.charAt(0) == t.charAt(0)) {
				dp[0][0] = 1;
			}
			for (int i = 1; i < len; i++) {
				if (s.charAt(i) == t.charAt(0)) {
					dp[0][i] = dp[0][i - 1] + 1;
				} else {
					dp[0][i] = dp[0][i - 1];
				}
			}

			for (int i = 1; i < len1; i++) {
				dp[i][0] = 0;
			}

			for (int i = 1; i < len1; i++) {
				for (int j = 1; j < len; j++) {

					if (t.charAt(i) == s.charAt(j)) {
						dp[i][j] = dp[i - 1][j - 1] + dp[i][j - 1];
					} else {
						dp[i][j] = dp[i][j - 1];
					}
				}
			}
			return dp[len1 - 1][len - 1];
		}
	}




	public void createFrame() {
		createA = new JFrame();
		createA.setLayout(new BorderLayout());
		
		JPanel aInfo = new JPanel(new GridLayout(8,1));
		
		JPanel personal = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JLabel pinfo = new JLabel("Enter registration information");
		pinfo.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		personal.add(pinfo);
		
		JPanel eInput = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JTextField em = new JTextField(40);
		em.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		JLabel email = new JLabel("Email");
		email.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		eInput.add(email);
		eInput.add(em);
		
		JPanel nInput = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JTextField name = new JTextField(20);
		name.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		JLabel fName = new JLabel("Full Name");
		fName.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		nInput.add(fName);
		nInput.add(name);
		
		JPanel aInput = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JTextField addr = new JTextField(30);
		addr.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		JLabel address = new JLabel("Home Address");
		address.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		aInput.add(address);
		aInput.add(addr);
		
		JPanel postInput = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JTextField postal = new JTextField(5);
		postal.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		JLabel pCode = new JLabel("Postal Code");
		pCode.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		postInput.add(pCode);
		postInput.add(postal);
		
		JPanel proInput = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JTextField province = new JTextField(15);
		province.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		JLabel prov = new JLabel("Province");
		prov.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		proInput.add(prov);
		proInput.add(province);
		
		JPanel phoneInput = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JTextField phone = new JTextField(10);
		phone.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		JLabel phoneNum = new JLabel("Phonenumber");
		phoneNum.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		phoneInput.add(phoneNum);
		phoneInput.add(phone);
		
		JPanel pInput = new JPanel(new FlowLayout(FlowLayout.LEFT));
		JTextField p = new JTextField(20);
		p.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		
		JLabel pW = new JLabel("Password");
		pW.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		pInput.add(pW);
		pInput.add(p);
		
		
		JPanel eBut = new JPanel(new FlowLayout());
		JButton enterBut = new JButton("Login");
		enterBut.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		enterBut.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String email = em.getText();
				String fullname = name.getText();
				String address = addr.getText() + " " + postal.getText() + " " + province.getText();
				String phonenum = phone.getText();
				String pIn =  p.getText();
				
				String query = "insert into customer values ('" + email + "', '" + fullname + "', '" + address + "', '" + phonenum + "', '" + pIn + "')";
				
				try(Connection c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bookstore", "postgres", "123456"); Statement s = c.createStatement();){
					s.executeQuery(query);
					
					
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
				
				JOptionPane.showMessageDialog(new JFrame(), "Account Created Log in now");
				createA.dispose();
			}
			
		});
		
		eBut.add(enterBut);
		
		aInfo.add(personal);
		aInfo.add(eInput);
		aInfo.add(nInput);
		aInfo.add(aInput);
		aInfo.add(postInput);
		aInfo.add(proInput);
		aInfo.add(phoneInput);
		aInfo.add(pInput);
		
		createA.add(aInfo, BorderLayout.CENTER);
		createA.add(eBut, BorderLayout.SOUTH);
		createA.pack();
		createA.setVisible(true);
	}
	class sobook {
		public  double findMedianSortedArrays(int[] nums1, int[] nums2) {
			int i=0;int j=0;int k=0;int l=0;
			k = (nums1.length+nums2.length+1)/2;
			while(i<nums1.length&&j<nums2.length)
			{
				if(nums1[i]<nums2[j])
				{
					l=nums1[i];
					i++;
					k--;
				}
				else
				{
					l=nums2[j];
					j++;
					k--;
				}
				if(k==0)
				{
					if((nums1.length+nums2.length)%2!=0)
						return Double.valueOf(l);
					else{
						if(i!=nums1.length&&j!=nums2.length)
						{
							if(nums1[i]<nums2[j])
							{
								return (l+nums1[i])/2.0;
							}
							else {
								return (l+nums2[j])/2.0;
							}
						}else if(i!=nums1.length)
						{
							return (l+nums1[i])/2.0;
						}else {
							return (l+nums2[j])/2.0;
						}
					}
				}
			}
			if((nums1.length+nums2.length)%2!=0)
			{
				if(i!=nums1.length)
				{
					return Double.valueOf(nums1[i+k-1]);
				}else
				{
					return Double.valueOf(nums2[j+k-1]);
				}
			}else{
				if(i!=nums1.length)
				{
					return (nums1[i+k-1]+nums1[i+k])/2.0;
				}else
				{
					return (nums2[j+k-1]+nums2[j+k])/2.0;
				}
			}

		}
	}
	class mains {
		public boolean isMatch(String s, String p) {
			if(p.isEmpty()) return s.isEmpty();

			int len = p.length();
			String indexE = "";
			for(int i = 0; i < len; i++) {
				indexE += "*";
			}

			if(s.isEmpty()) {
				return p.isEmpty() || p.equals(indexE);
			}

			if(p.indexOf("*") == -1) {
				if(p.length() != s.length()) return false;
				if(p.charAt(0)!=s.charAt(0) && p.charAt(0) != '?') return false;
				return isMatch(s.substring(1),p.substring(1));
			}

			List<String> pList = new LinkedList<>();
			pList.add(p);
			pList = splitStr(pList,indexE);

			for(int i = 0; i < pList.size(); i++) {
				s = partlyMatch(s,pList.get(i),i==0,i==pList.size()-1);
				if(s == null) return false;
			}

			return true;
		}

		private List<String> splitStr(List<String> p,String indexE) {
			if(indexE.isEmpty()) return p;
			List<String> sList = new LinkedList<>();
			for(String s: p) {
				if(s.indexOf(indexE) < 0) sList.add(s);
				else {
					String[] tmp = split(s,indexE);
					for(int j = 0; j < tmp.length; j++) {
						sList.add(tmp[j]);
					}
				}
			}
			return splitStr(sList,indexE.substring(1));
		}

		private String[] split(String s, String exp) {
			if(exp.isEmpty()) return s.split("");
			int len = exp.length();
			int lastIndex = 0,count = 1;
			String[] tmp = new String[s.length()+1];
			for(int i = 0; i <= s.length() - len;) {
				if(s.substring(i,i+len).equals(exp)) {
					tmp[i] = s.substring(lastIndex,i);
					lastIndex = i+len;
					i = i+len;
					count++;
				}else {
					i++;
				}
			}
			tmp[s.length()] = s.substring(lastIndex);
			String[] res = new String[count];
			for(int i = tmp.length - 1; i >=0; i--) {
				if(tmp[i] != null) res[--count] = tmp[i];
			}
			return res;
		}

		private String partlyMatch(String s, String p,boolean isFirst, boolean isLast) {
			if(p.isEmpty()) return s;
			if(p.length() > s.length()) return null;
			int si = 0,pi = 0;
			if(isLast) {
				si = s.length()-1;
				pi = p.length()-1;
				for(; pi >= 0; pi--) {
					if(s.charAt(si) != p.charAt(pi) && p.charAt(pi) != '?')
						return null;
					si--;
				}
				return "";
			}else {
				for(; si < s.length(); si++) {
					if(pi == p.length()) break;
					if(s.charAt(si) == p.charAt(pi) || p.charAt(pi) == '?') {
						pi++;
					}else {
						si -= pi;
						pi = 0;
					}
				}
			}
			if(pi < p.length()) return null;
			if(isFirst && si != pi) return null;
			return s.substring(si);
		}
	}

	public static void main(String[] args) {
		index_Main view = new index_Main(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		String a = e.getActionCommand();
		if(a.equals("Login")) {
			this.signIn();
		}
		else if(a.equals("Register")) {
			this.createFrame();
		}
		else if(a.contentEquals("Guest")) {
			first.dispose();
			store = new mall_Interface(false, "Guest");
		}
		
	}
}
class index {
	public static double findMedianSortedArrays(int[] nums1, int[] nums2) {
		boolean isNums1Start = true;
		int[] nums3;
		if(nums1 !=null && nums1.length>0){
			if(nums2 !=null && nums2.length>0){
				isNums1Start = nums1[0]<nums2[0];
				nums3 = new int[nums1.length + nums2.length];
			}else{
				isNums1Start = true;
				nums3 = new int[nums1.length];
			}
		}else{
			isNums1Start = false;
			nums3 = new int[nums2.length];
		}
		int index = 0;
		int i = 0;
		while(i<(isNums1Start?nums1.length:nums2.length)){
			if(isNums1Start){
				nums3[i+index] = nums1[i];
				i++;
				if(nums2 !=null){
					while(index < nums2.length && ((nums1.length>i && nums2[index]<nums1[i])|| nums1.length==i)){
						nums3[i+index] = nums2[index];
						index++;
					}
				}
			}else{
				nums3[i+index] = nums2[i];
				i++;
				if(nums1 !=null){
					while(index < nums1.length && ((nums2.length>i && nums1[index]<nums2[i])|| nums2.length==i)){
						nums3[i+index] = nums1[index];
						index++;
					}
				}
			}
		}
		if(nums3.length%2==0){
			return (float)(nums3[nums3.length/2] + nums3[nums3.length/2-1])/2;
		}else{
			return (float)nums3[nums3.length/2];
		}
	}
}
