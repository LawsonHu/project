import java.awt.BorderLayout;

import javax.swing.*;

public class book_Interface extends JFrame{

	

	private static final long serialVersionUID = 4L;

	public book_Interface() {
		super("Cart");
		this.setLayout(new BorderLayout());
	}
	public void showCart() {
		this.setVisible(true);
	}
	public void addToCart(String title, int quantity) {
	}
	class book {
		// (（n+m+1)/2+(n+m+2)/2)/2。
		public double findMedianSortedArrays(int[] arr1, int[] arr2) {
			int n = arr1.length;
			int m = arr2.length;
			return (findKth(arr1, arr2,(n+m+1)/2) + findKth(arr1,arr2,(n+m+2)/2))/2.0;
		}

		public int findKth(int[] arr1, int[] arr2, int k) {
			if(arr1 == null || arr1.length < 1)
				return arr2[k-1];
			if(arr2 == null || arr2.length < 1)
				return arr1[k-1];

			return findKth(arr1, 0, arr1.length - 1, arr2, 0, arr2.length - 1, k);
		}

		public int findKth(int[] arr1, int l1, int r1, int[] arr2, int l2, int r2, int k) {
			if(l1 > r1)
				return arr2[l2 + k - 1];
			if(l2 > r2)
				return arr1[l1 + k - 1];
			if (k <= 1)
				return Math.min(arr1[l1],arr2[l2]);
			int md1 = l1 + k/2 - 1 <= r1 ? l1 + k/2 - 1: r1;
			int md2 = l2 + k/2  - 1 <= r2 ? l2 + k/2 - 1: r2;
			if(arr1[md1] < arr2[md2])
				return findKth(arr1, md1 + 1, r1, arr2, l2, r2, k - (md1-l1+1));
			else
				return findKth(arr1, l1, r1, arr2, md2 + 1, r2, k - (md2-l2+1));
		}
	}

}



class mall {
	private char[] s, p;
	private int[][] memo;
	public boolean isMatch(String s, String p) {

		if (p.length() == 0) {
			return s.length() == 0;
		}
		if (s.length() == 0) {
			for (int i = 0; i < p.length(); i++) {
				if (p.charAt(i) != '*') {
					return false;
				}
			}
			return true;
		}

		this.s = s.toCharArray();

		StringBuilder sb = new StringBuilder();
		sb.append(p.charAt(0)) ;
		for (int i = 1; i < p.length(); i++) {
			if (p.charAt(i) != '*' || p.charAt(i - 1) != '*') {
				sb.append(p.charAt(i));
			}
		}
		this.p = sb.toString().toCharArray();
		int n = this.s.length, m = this.p.length;
		memo = new int[n + 1][m + 1];
		return dfs(0, 0);
	}

	private boolean dfs(int i, int j) {

		while (i < s.length && j < p.length &&
				(s[i] == p[j] || p[j] == '?')) {
			i++;
			j++;
		}
		if (memo[i][j] > 0) {
			return memo[i][j] == 1;
		}

		if (i == s.length) {
			boolean res = j == p.length || (j == p.length - 1 && p[j] == '*');
			memo[i][j] = res ? 1 : 2;
			return res;
		}
		if (j == p.length) {
			memo[i][j] = 2;
			return false;
		}

		if (p[j] != '*' && s[i] != p[j]) {
			memo[i][j] = 2;
			return false;
		}
		//
		// i <= k <= s.length
		// k == i
		// k == s.length
		for (int k = i; k <= s.length; k++) {
			if (dfs(k, j + 1)) {
				memo[i][j] = 1;
				return true;
			}
		}
		memo[i][j] = 2;
		return false;
	}
}