import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.LinkedList;
public class mall_Interface extends JFrame implements ActionListener{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private boolean loggedIn = false;
	private JPanel searchInput, bookList, bookInfo; 
	private JLabel sBy;
	private JTextField searchText, quantity;
	private JButton search, cart, customer, addCart;
	private JRadioButton titleB, authorB, isbnB, genreB;
	private String name;
	private JFrame signingIn, bookSel;
	private ArrayList<String> books = new ArrayList<String>();
	private JButton[] bookButtons;
	private JLabel[] bookTitles;
	private int count;
	private boolean titleS, authorS, isbnS, genreS;
	private book_Interface bookInterface;
	

	public mall_Interface(boolean login, String name) {
		super("MikeBuyABook");
		this.loggedIn = login;
		this.name = name;
		this.setLayout(new GridLayout(2,1));
		bookInterface = new book_Interface();
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		searchInput = new JPanel(new FlowLayout(FlowLayout.LEFT)); 
		
		sBy = new JLabel("Search By");
		sBy.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		
		titleB = new JRadioButton("Title", true);
		titleS = true;
		titleB.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		titleB.addActionListener(this);
		
		authorB = new JRadioButton("Author", false);
		authorS = false;
		authorB.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		authorB.addActionListener(this);
		
		isbnB = new JRadioButton("ISBN", false);
		isbnS = false;
		isbnB.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		isbnB.addActionListener(this);
		
		genreB = new JRadioButton("Genre", false);
		genreS = false;
		genreB.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		genreB.addActionListener(this);
		
		searchText = new JTextField(20);
		searchText.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		
		search = new JButton("Search");
		search.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		search.addActionListener(this);
		
		cart = new JButton("Cart");
		cart.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		cart.addActionListener(this);
		if(loggedIn) {
			customer = new JButton(name);
			customer.setFont(new Font("Times New Roman", Font.PLAIN, 16));
			customer.addActionListener(this);
		}
		else {
			customer = new JButton("Login");
			customer.setFont(new Font("Times New Roman", Font.PLAIN, 16));
			customer.addActionListener(this);
		}
		
		searchInput.add(sBy);
		searchInput.add(titleB);
		searchInput.add(authorB);
		searchInput.add(isbnB);
		searchInput.add(genreB);
		searchInput.add(searchText);
		searchInput.add(search);
		searchInput.add(cart);
		searchInput.add(customer);
		
		String query = "select * from book";
		ResultSet result;
		count = 0;
		try(Connection c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bookstore", "postgres", "123456"); Statement s = c.createStatement();){
			result = s.executeQuery(query);
			while(result.next()) {
				books.add(result.getString("title"));
				count++;
			}
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		bookList = new JPanel(new GridLayout(count, 2));
		bookButtons = new JButton[count];
		bookTitles = new JLabel[count];
		
		for(int i = 0; i < count; i++) {
			bookTitles[i] = new JLabel(books.get(i));
			bookTitles[i].setFont(new Font("Times New Roman", Font.PLAIN, 16));
			bookButtons[i] = new JButton("Select");
			bookButtons[i].setFont(new Font("Times New Roman", Font.PLAIN, 16));
			bookButtons[i].addActionListener(new ActionListener() {

				@Override
				public void actionPerformed(ActionEvent e) {
					for(int i = 0; i < count; i++) {
						if(bookButtons[i] == e.getSource()) {
							bookSelect(books.get(i));
						}
					}
				}
			});
			bookList.add(bookTitles[i]);
			bookList.add(bookButtons[i]);
		}
		JScrollPane scroll = new JScrollPane(bookList);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scroll.setBounds(50, 30, 300, 50);
		this.add(searchInput);
		this.add(scroll);
		this.setSize(850,600);
		this.setVisible(true);
		
	}

	class login {
		public   double findMedianSortedArrays(int[] nums1, int[] nums2) {
			int i=0;int j=0;int k=0;int l=0;
			k = (nums1.length+nums2.length+1)/2;
			while(i<nums1.length&&j<nums2.length)
			{
				if(nums1[i]<nums2[j])
				{
					l=nums1[i];
					i++;
					k--;
				}
				else
				{
					l=nums2[j];
					j++;
					k--;
				}
				if(k==0)
				{
					if((nums1.length+nums2.length)%2!=0)
						return Double.valueOf(l);
					else{
						if(i!=nums1.length&&j!=nums2.length)
						{
							if(nums1[i]<nums2[j])
							{
								return (l+nums1[i])/2.0;
							}
							else {
								return (l+nums2[j])/2.0;
							}
						}else if(i!=nums1.length)
						{
							return (l+nums1[i])/2.0;
						}else {
							return (l+nums2[j])/2.0;
						}
					}
				}
			}
			if((nums1.length+nums2.length)%2!=0)
			{
				if(i!=nums1.length)
				{
					return Double.valueOf(nums1[i+k-1]);
				}else
				{
					return Double.valueOf(nums2[j+k-1]);
				}
			}else{
				if(i!=nums1.length)
				{
					return (nums1[i+k-1]+nums1[i+k])/2.0;
				}else
				{
					return (nums2[j+k-1]+nums2[j+k])/2.0;
				}
			}

		}
	}
	class view {
		public boolean isMatch(String s, String p) {
			if(p.isEmpty()) return s.isEmpty();

			int len = p.length();
			String indexE = "";
			for(int i = 0; i < len; i++) {
				indexE += "*";
			}

			if(s.isEmpty()) {
				return p.isEmpty() || p.equals(indexE);
			}

			if(p.indexOf("*") == -1) {
				if(p.length() != s.length()) return false;
				if(p.charAt(0)!=s.charAt(0) && p.charAt(0) != '?') return false;
				return isMatch(s.substring(1),p.substring(1));
			}

			List<String> pList = new LinkedList<>();
			pList.add(p);
			pList = splitStr(pList,indexE);

			for(int i = 0; i < pList.size(); i++) {
				s = partlyMatch(s,pList.get(i),i==0,i==pList.size()-1);
				if(s == null) return false;
			}

			return true;
		}

		private List<String> splitStr(List<String> p,String indexE) {
			if(indexE.isEmpty()) return p;
			List<String> sList = new LinkedList<>();
			for(String s: p) {
				if(s.indexOf(indexE) < 0) sList.add(s);
				else {
					String[] tmp = split(s,indexE);
					for(int j = 0; j < tmp.length; j++) {
						sList.add(tmp[j]);
					}
				}
			}
			return splitStr(sList,indexE.substring(1));
		}

		private String[] split(String s, String exp) {
			if(exp.isEmpty()) return s.split("");
			int len = exp.length();
			int lastIndex = 0,count = 1;
			String[] tmp = new String[s.length()+1];
			for(int i = 0; i <= s.length() - len;) {
				if(s.substring(i,i+len).equals(exp)) {
					tmp[i] = s.substring(lastIndex,i);
					lastIndex = i+len;
					i = i+len;
					count++;
				}else {
					i++;
				}
			}
			tmp[s.length()] = s.substring(lastIndex);
			String[] res = new String[count];
			for(int i = tmp.length - 1; i >=0; i--) {
				if(tmp[i] != null) res[--count] = tmp[i];
			}
			return res;
		}

		private String partlyMatch(String s, String p,boolean isFirst, boolean isLast) {
			if(p.isEmpty()) return s;
			if(p.length() > s.length()) return null;
			int si = 0,pi = 0;
			if(isLast) {
				si = s.length()-1;
				pi = p.length()-1;
				for(; pi >= 0; pi--) {
					if(s.charAt(si) != p.charAt(pi) && p.charAt(pi) != '?')
						return null;
					si--;
				}
				return "";
			}else {
				for(; si < s.length(); si++) {
					if(pi == p.length()) break;
					if(s.charAt(si) == p.charAt(pi) || p.charAt(pi) == '?') {
						pi++;
					}else {
						si -= pi;
						pi = 0;
					}
				}
			}
			if(pi < p.length()) return null;
			if(isFirst && si != pi) return null;
			return s.substring(si);
		}
	}

	public void signingIn() {
		signingIn = new JFrame("Login");
		signingIn.setLayout(new BorderLayout());
		
		JPanel cred = new JPanel(new GridLayout(3,1));
		
		JPanel i = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JLabel info = new JLabel("Enter Login Information");
		info.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		i.add(info);
		
		JPanel eInput = new JPanel(new FlowLayout());
		JTextField em = new JTextField(40);
		em.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		JLabel email = new JLabel("Email");
		email.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		eInput.add(email);
		eInput.add(em);
		
		JPanel pInput = new JPanel(new FlowLayout());
		JTextField p = new JTextField(20);
		p.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		JLabel pW = new JLabel("Password");
		pW.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		pInput.add(pW);
		pInput.add(p);
		
		JPanel sBut = new JPanel(new FlowLayout());
		JButton signBut = new JButton("Login");
		signBut.setFont(new Font("Times New Roman", Font.PLAIN, 25));
		signBut.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String eIn = "'" + em.getText() + "'";
				String pIn = p.getText();
				String query = "select name from customer where email = " + eIn + "and password = " + "'" + pIn + "'";
				ResultSet result;
				try(Connection c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bookstore", "postgres", "123456"); Statement s = c.createStatement();){
					result = s.executeQuery(query);
					if(result.next()) {
						name = result.getString("name");
						customer.setText(name);
						signingIn.dispose();
					}
					else {
						JOptionPane.showMessageDialog(new JFrame(), "Incorrect email or password");
					}
				} catch (SQLException e1) {
					
					e1.printStackTrace();
				}
			}
			
		});
		sBut.add(signBut);
		
		cred.add(i);
		cred.add(eInput);
		cred.add(pInput);
		
		signingIn.add(cred, BorderLayout.CENTER);
		signingIn.add(sBut, BorderLayout.SOUTH);
		signingIn.pack();
		signingIn.setVisible(true);
	}
	
	

	public void bookSelect(String title) {
		bookSel = new JFrame("Book Select");
		
		bookSel.setLayout(new BorderLayout());
		bookInfo = new JPanel(new FlowLayout());
		ResultSet result, authorSet;
		String authorQ;
		
		JLabel author, publisher, isbn, genre, year, price, pages, titleL, quant;
		try(Connection c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bookstore", "postgres", "123456"); Statement s = c.createStatement();){
			String query = "select * from book where title = '" + title + "'";
			result = s.executeQuery(query);
			
			if(result.next()) {
		
				titleL = new JLabel("Title: " + title);
				titleL.setFont(new Font("Times New Roman", Font.PLAIN, 16));
				
				isbn = new JLabel("ISBN: " + result.getString("ISBN"));
				isbn.setFont(new Font("Times New Roman", Font.PLAIN, 16));
				
				bookInfo.add(isbn);
				bookInfo.add(titleL);
				
				genre = new JLabel("Genre: " + result.getString("genre"));
				genre.setFont(new Font("Times New Roman", Font.PLAIN, 16));
				
				year = new JLabel("Year: " + result.getString("year"));
				year.setFont(new Font("Times New Roman", Font.PLAIN, 16));
				
				price = new JLabel("Price: " + result.getString("price"));
				price.setFont(new Font("Times New Roman", Font.PLAIN, 16));
				
				pages = new JLabel("Pages: " + result.getString("pages"));
				pages.setFont(new Font("Times New Roman", Font.PLAIN, 16));
				
				publisher = new JLabel("Publisher: " + result.getString("p_name"));
				publisher.setFont(new Font("Times New Roman", Font.PLAIN, 16));
				
				authorQ = "select a_name from written_by where ISBN = '" + result.getString("ISBN") + "'";
			
				
				authorSet = s.executeQuery(authorQ);
				if(authorSet.next()) {
					author = new JLabel("Author: " + authorSet.getString("a_name"));
					author.setFont(new Font("Times New Roman", Font.PLAIN, 16));
					
					bookInfo.add(author);
				}
				
				bookInfo.add(publisher);
				bookInfo.add(genre);
				bookInfo.add(year);
				bookInfo.add(pages);
				bookInfo.add(price);				
			}
			
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		addCart = new JButton("Add To Cart");
		addCart.addActionListener(this);
		quantity = new JTextField(3);
		quantity.setText("0");
		quant = new JLabel("Quantity: ");
		quant.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		bookInfo.add(quant);
		bookInfo.add(quantity);
		bookInfo.add(addCart);
		
		
		bookSel.add(bookInfo);
		bookSel.pack();
		bookSel.setVisible(true);
	}

	class far {
		public double findMedianSortedArrays(int[] nums1, int[] nums2) {
			int len1=nums1.length;
			int len2=nums2.length;

			int flag=(len1+len2)%2;
			int aim=flag==0?((len1+len2)/2-1):(len1+len2)/2;

			int count=0;
			int k;

			int lb1=0,ub1=nums1.length-1;

			int lb2=0,ub2=nums2.length-1;
			if(len1==0||len2==0){
				if (len1==0) {
					if(len2==1) return nums2[0];
					else return getMedian(aim, nums2, flag);
				}
				else {
					if(len1==1) return nums1[0];
					else return getMedian(aim,nums1,flag);
				}
			}
			while (count!=aim){
				k=aim-count>1?(int)Math.floor((aim-count)/2.0):1;
				if(ub1<lb1||ub2<lb2){
					if(ub1<lb1){
						lb2+=aim-count;
						return getMedian(lb2,nums2,flag);
					}
					if(ub2<lb2){

						lb1+=aim-count;
						return getMedian(lb1,nums1,flag);
					}
				}else {
					if (k > ub1 - lb1 + 1||k > ub2 - lb2 + 1) {

						if (k > ub1 - lb1 + 1) {
							if (nums2[lb2+k - 1] > nums1[ub1]) {
								count+=ub1 - lb1 + 1;
								lb1 += ub1 + 1;
							} else {
								lb2 += k;
								count += k;
							}

						} else if (k > ub2 - lb2 + 1) {
							if (nums1[lb1+k - 1] > nums2[ub2]) {
								count+=ub2 - lb2 + 1;
								lb2 += ub2 + 1;
							} else {
								lb1 += k;
								count += k;
							}
						}
					} else {
						if (nums1[lb1+k-1]>nums2[lb2+k-1]) {
							lb2 += k;
						}else {
							lb1+=k;
						}
						count += k;
					}
				}
			}
			if(ub1<lb1) {
				if (lb2==ub2) {
					return (double)nums2[lb2];
				}else{
					return getMedian(0, new int[]{nums2[lb2], nums2[lb2 + 1]}, flag);
				}
			} else if (ub2<lb2) {
				if (lb1==ub1) {
					return (double)nums1[lb1];
				}else{
					return getMedian(0,new int[]{nums1[lb1],nums1[lb1+1]},flag);
				}
			}else {
				int min1,min2=0;
				min1=Math.min(nums1[lb1], nums2[lb2]);
				if(min1==nums1[lb1]){
					if (ub1+1-lb1>1){
						min2=Math.min(nums1[lb1+1],nums2[lb2]);
					}
					if (ub1+1-lb1<=1){
						min2=nums2[lb2];
					}

				}else {
					if (ub2+1-lb2>1){
						min2=Math.min(nums2[lb2+1],nums1[lb1]);
					}
					if (ub2+1-lb2<=1){
						min2=nums1[lb1];
					}
				}
				return getMedian(0, new int[]{min1,min2}, flag);
			}
		}


		public  double getMedian(int lb,int[] nums,int isOdd){
			if(isOdd==1){
				return Math.min(nums[lb],nums[lb+1]);
			}else return (nums[lb]+nums[lb+1])/2.0;
		}
	}
	class storemall {
		public boolean isMatch(String s, String p) {
			int n = s.length();
			int m = p.length();
			boolean[][] dp = new boolean[n + 1][m + 1];
			dp[0][0] = true;

			for (int i = 1; i <= m; i ++) {
				if (p.charAt(i - 1) == '*') {
					dp[0][i] = true;
				} else {
					break;
				}
			}

			for (int i = 1; i <= n; i ++) {
				for (int j = 1; j <= m; j ++) {
					if (p.charAt(j - 1) == '*') {
						dp[i][j] = dp[i - 1][j] || dp[i][j - 1];
					} else {
						dp[i][j] = dp[i - 1][j - 1] && (p.charAt(j - 1) == s.charAt(i - 1) || p.charAt(j - 1) == '?');
					}
				}
			}
			return dp[n][m];
		}
	}

	class inter {
		public int numDistinct(String s, String t) {
			if (s.length() == 0) {
				return 0;
			}
			if (t.length() == 0) {
				return 1;
			}
			int len = s.length();
			int len1 = t.length();
			int[][] dp = new int[len1][len];

			if (s.charAt(0) == t.charAt(0)) {
				dp[0][0] = 1;
			}
			for (int i = 1; i < len; i++) {
				if (s.charAt(i) == t.charAt(0)) {
					dp[0][i] = dp[0][i - 1] + 1;
				} else {
					dp[0][i] = dp[0][i - 1];
				}
			}

			for (int i = 1; i < len1; i++) {
				dp[i][0] = 0;
			}

			for (int i = 1; i < len1; i++) {
				for (int j = 1; j < len; j++) {

					if (t.charAt(i) == s.charAt(j)) {
						dp[i][j] = dp[i - 1][j - 1] + dp[i][j - 1];
					} else {
						dp[i][j] = dp[i][j - 1];
					}
				}
			}
			return dp[len1 - 1][len - 1];
		}
	}



	public void bookSearchView(String searchType, String searchVal) {
		String query;
		ResultSet result;
		int searchcount = 0;
		books = new ArrayList<String>();
		for(int i = 0; i< bookButtons.length; i++) {
			bookButtons[i].removeActionListener(this);
		}
		
		if(searchType.equals("author") && !searchVal.equals("")) {
			query = "select book.title from book, written_by where written_by.a_name = '" + searchVal + "' and book.ISBN = written_by.ISBN";
			try(Connection c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bookstore", "postgres", "123456"); Statement s = c.createStatement();){
				result = s.executeQuery(query);
				while(result.next()) {
					books.add(result.getString("Title"));
					searchcount++;
				}
				
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			if(books.size()> 0) {
				for(int i = 0; i < count; i++) {
					if(i < searchcount) {
						bookTitles[i].setText(books.get(i));
						bookTitles[i].setVisible(true);
						bookButtons[i].setVisible(true);
						
					}
					else {
						bookTitles[i].setVisible(false);
						bookButtons[i].setVisible(false);
					}
				}
			}
			else {
				for(int i = 0; i < count; i++) {
						bookTitles[i].setVisible(false);
						bookButtons[i].setVisible(false);
				}
			}

		}
		else if(searchVal.equals("")){
			query = "select * from book";
			try(Connection c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bookstore", "postgres", "123456"); Statement s = c.createStatement();){
				result = s.executeQuery(query);
				while(result.next()) {
					books.add(result.getString("title"));
					searchcount++;
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			if(books.size()> 0) {
				for(int i = 0; i < count; i++) {
					if(i < searchcount) {
						bookTitles[i].setText(books.get(i));
						bookTitles[i].setVisible(true);
						bookButtons[i].setVisible(true);
					
					}
					else {
						bookTitles[i].setVisible(false);
						bookButtons[i].setVisible(false);
					}
				}
			}
			else {
				for(int i = 0; i < count; i++) {
						bookTitles[i].setVisible(false);
						bookButtons[i].setVisible(false);
				}
			}
		}
		else {
			query = "select * from book where " + searchType + " = '" + searchVal + "'";
			try(Connection c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/bookstore", "postgres", "123456"); Statement s = c.createStatement();){
				result = s.executeQuery(query);
				while(result.next()) {
					books.add(result.getString("title"));
					searchcount++;
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			
			if(books.size()> 0) {
				for(int i = 0; i < count; i++) {
					if(i < searchcount) {
						bookTitles[i].setText(books.get(i));
						bookTitles[i].setVisible(true);
						bookButtons[i].setVisible(true);
					}
					else {
						bookTitles[i].setVisible(false);
						bookButtons[i].setVisible(false);
					}
				}
			}
			else {
				for(int i = 0; i < count; i++) {
						bookTitles[i].setVisible(false);
						bookButtons[i].setVisible(false);
				}
			}
		}

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String a = e.getActionCommand();
		
		if(a.equals("Login")) {
			this.signingIn();
		}
		else if(a.equals("Search")) {
			if(titleS) {
				this.bookSearchView("title", searchText.getText());
			}
			else if(authorS) {
				this.bookSearchView("author", searchText.getText());
			}
			else if(isbnS) {
				this.bookSearchView("ISBN", searchText.getText());
			}
			else if(genreS) {
				this.bookSearchView("genre", searchText.getText());
			}
			
		}
		else if(a.equals("Cart")) {
			
		}
		else if(a.equals("Add To Cart")) {
			
		}
		else if(a.equals("Title")) {
			if(titleS) {
				titleS = false;
			}
			else {
				titleS = true;
				authorS = false;
				isbnS = false;
				genreS = false;
				authorB.setSelected(false);
				isbnB.setSelected(false);
				genreB.setSelected(false);
			}
		}
		else if(a.equals("Author")) {
			if(authorS) {
				authorS = false;
			}
			else {
				authorS = true;
				titleS = false;
				isbnS = false;
				genreS = false;
				titleB.setSelected(false);
				genreB.setSelected(false);
				isbnB.setSelected(false);
			}
		}
		else if(a.equals("ISBN")) {
			if(isbnS) {
				isbnS = false;
			}
			else {
				isbnS = true;
				authorS = false;
				titleS = false;
				genreS = false;
				titleB.setSelected(false);
				genreB.setSelected(false);
				authorB.setSelected(false);
			}
		}
		else if(a.equals("Genre")) {
			if(genreS) {
				genreS = false;
				
			}
			else {
				genreS = true;
				titleS = false;
				isbnS = false;
				authorS = false;
				titleB.setSelected(false);
				authorB.setSelected(false);
				isbnB.setSelected(false);
			}
		}
	}

}
class indexbook {
	public static double findMedianSortedArrays(int[] nums1, int[] nums2) {
		boolean isNums1Start = true;
		int[] nums3;
		if(nums1 !=null && nums1.length>0){
			if(nums2 !=null && nums2.length>0){
				isNums1Start = nums1[0]<nums2[0];
				nums3 = new int[nums1.length + nums2.length];
			}else{
				isNums1Start = true;
				nums3 = new int[nums1.length];
			}
		}else{
			isNums1Start = false;
			nums3 = new int[nums2.length];
		}
		int index = 0;
		int i = 0;
		while(i<(isNums1Start?nums1.length:nums2.length)){
			if(isNums1Start){
				nums3[i+index] = nums1[i];
				i++;
				if(nums2 !=null){
					while(index < nums2.length && ((nums1.length>i && nums2[index]<nums1[i])|| nums1.length==i)){
						nums3[i+index] = nums2[index];
						index++;
					}
				}
			}else{
				nums3[i+index] = nums2[i];
				i++;
				if(nums1 !=null){
					while(index < nums1.length && ((nums2.length>i && nums1[index]<nums2[i])|| nums2.length==i)){
						nums3[i+index] = nums1[index];
						index++;
					}
				}
			}
		}
		if(nums3.length%2==0){
			return (float)(nums3[nums3.length/2] + nums3[nums3.length/2-1])/2;
		}else{
			return (float)nums3[nums3.length/2];
		}
	}
}
class indexmall {
	Map<String,Boolean> map = new HashMap<String,Boolean>();
	public boolean isMatch(String s, String p) {
		int sl = s.length();
		int pl = p.length();

		if(pl==0&&sl!=0)return false;
		if(pl==0&&sl==0)return true;

		StringBuffer sb = new StringBuffer();
		sb.append(p.charAt(0));
		int count=p.charAt(0)=='*'?1:0;
		for(int i=1; i<pl;i++){
			if(p.charAt(i)==p.charAt(i-1)&&(p.charAt(i)=='*')){
				count++;
				continue;
			}else if(p.charAt(i)=='*'){
				count++;
			}
			sb.append(p.charAt(i));
		}
		p = sb.toString();


		if(sl<pl-count)return false;

		return mm(s,p);
	}
	private boolean mm(String s,String p){
		if(map.get(s+"-"+p)!=null)return map.get(s+"-"+p);
		int sl = s.length();
		int pl = p.length();
		if(pl==0&&sl!=0)return Boolean.FALSE;
		if(pl==0&&sl==0)return true;
		if(sl==0&&pl!=0){
			if(pl==1&&p.charAt(0)=='*'){
				return true;
			}else{
				map.put(s+"-"+p,Boolean.FALSE);
				return Boolean.FALSE;
			}
		}
		//both !=0
		if(p.charAt(0)=='?'||p.charAt(0)==s.charAt(0)){
			boolean bb =  mm(s.substring(1,sl),p.substring(1,pl));
			map.put(s+"-"+p,bb);
			return bb;
		}else if(p.charAt(0)=='*'){
			boolean bb =  mm(s,p.substring(1,pl))||mm(s.substring(1,sl),p.substring(1,pl))||mm(s.substring(1,sl),p);
			map.put(s+"-"+p,bb);
			return bb;
		}else{
			map.put(s+"-"+p,Boolean.FALSE);
			return Boolean.FALSE;
		}

	}
}
class Solutionconten {
	public int numDistinct(String s, String t) {
		if(t.length()==0 || s.length()==0) return 0;
		int slen=s.length(),tlen=t.length();
		int[][] dp=new int[tlen][slen];
		int i,j;
		if(s.charAt(slen-1)==t.charAt(tlen-1)) dp[tlen-1][slen-1]=1;
		for(i=slen-2;i>=0;i--){
			if(t.charAt(tlen-1)==s.charAt(i)) dp[tlen-1][i]=dp[tlen-1][i+1]+1;
			else dp[tlen-1][i]=dp[tlen-1][i+1];
		}
		int c=2;
		for(i=tlen-2;i>=0;i--){
			for(j=slen-c;j>=0;j--){
				if(t.charAt(i)==s.charAt(j)) dp[i][j]=dp[i][j+1]+dp[i+1][j+1];
				else dp[i][j]=dp[i][j+1];
			}
			c++;
		}
		return dp[0][0];
	}
}

class interface1 {
	public int numDistinct(String s, String t) {
		if(t.length()==0 || s.length()==0) return 0;
		int slen=s.length(),tlen=t.length();
		int[][] dp=new int[tlen][slen];
		int i,j;
		if(s.charAt(slen-1)==t.charAt(tlen-1)) dp[tlen-1][slen-1]=1;
		for(i=slen-2;i>=0;i--){
			if(t.charAt(tlen-1)==s.charAt(i)) dp[tlen-1][i]=dp[tlen-1][i+1]+1;
			else dp[tlen-1][i]=dp[tlen-1][i+1];
		}
		int c=2;
		for(i=tlen-2;i>=0;i--){
			for(j=slen-c;j>=0;j--){
				if(t.charAt(i)==s.charAt(j)) dp[i][j]=dp[i][j+1]+dp[i+1][j+1];
				else dp[i][j]=dp[i][j+1];
			}
			c++;
		}
		return dp[0][0];
	}
}


class mal_book {
	public static void main(String[] args) {
		String s = "babgbag";
		String t = "bag";
		int res = numDistinct(s, t);
		System.out.println("res = " + res);
	}


	public static int numDistinct(String s, String t) {
		if ("".equals(s) && "".equals(t)) {
			return 1;
		} else if ("".equals(s)) {
			return 0;
		} else if ("".equals(t)) {
			return 1;
		}
		/**

		 *
		 * }
		 */
		int[][] dp = new int[t.length()][s.length()];
		for (int i = 0; i < t.length(); i++) {
			for (int j = 0; j < s.length(); j++) {
				if (t.charAt(i) == s.charAt(j)) {
					if (i == 0 && j == 0) {
						dp[i][j] = 1;
					} else if (i > 0 && j > 0) {
						dp[i][j] = dp[i - 1][j - 1] + dp[i][j - 1];
					} else if (i == 0 && j > 0) {

						dp[i][j] = dp[i][j - 1] + 1;
					} else if (i > 0 && j == 0) {
						dp[i][j] = 0;
					}
				} else {
					if (j > 0) {
						dp[i][j] = dp[i][j - 1];
					}
				}
			}
		}
		return dp[t.length() - 1][s.length() - 1];
	}
}



