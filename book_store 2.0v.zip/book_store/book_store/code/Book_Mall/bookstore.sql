/*
 Navicat PostgreSQL Data Transfer

 Source Server         : postgresql

 Source Server Type    : PostgreSQL
 Source Server Version : 90514
 Source Host           : localhost:5432
 Source Catalog        : bookstore
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 90514
 File Encoding         : 65001

 Date: 05/12/2021 10:25:42
*/


-- ----------------------------
-- Table structure for author
-- ----------------------------
DROP TABLE IF EXISTS "author";
CREATE TABLE "author" (
  "a_name" varchar(40) COLLATE "pg_catalog"."default" NOT NULL,
  "address" varchar(50) COLLATE "pg_catalog"."default",
  "phone_num" numeric(10)
)
;

-- ----------------------------
-- Records of author
-- ----------------------------
BEGIN;
INSERT INTO "author" VALUES ('Rick Riordan', '63 First st', 4167583123);
INSERT INTO "author" VALUES ('J.R.R. Tolkien', '43 Tolkien st', 4167585321);
INSERT INTO "author" VALUES ('Jimmie Davis', '34 Ten st', 4167581232);
INSERT INTO "author" VALUES ('Caroline Jayne Church', '52 Dam st', 4167581232);
INSERT INTO "author" VALUES ('Sandra Boynton', '43 Fake st', 4167523233);
INSERT INTO "author" VALUES ('Daniel Howarth', '412 Fake st', 4167527893);
INSERT INTO "author" VALUES ('Patricia Mccowen', '76 Fake st', 4167521282);
INSERT INTO "author" VALUES ('Alex Light', '503 Fake st', 4167528198);
COMMIT;

-- ----------------------------
-- Table structure for book
-- ----------------------------
DROP TABLE IF EXISTS "book";
CREATE TABLE "book" (
  "isbn" numeric(13) NOT NULL,
  "title" varchar(60) COLLATE "pg_catalog"."default",
  "genre" varchar(20) COLLATE "pg_catalog"."default",
  "year" numeric(4),
  "price" numeric(5,2),
  "pages" numeric(4),
  "p_name" varchar(40) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of book
-- ----------------------------
BEGIN;
INSERT INTO "book" VALUES (9780261102217, 'The Hobbit', 'Fantasy', 2012, 10.99, 400, 'HarperCollins Publishers');
INSERT INTO "book" VALUES (9780261102354, 'The Lord of The Rings: The Fellowship Of The Ring', 'Fantasy', 2007, 10.99, 448, 'HarperCollins Publishers');
INSERT INTO "book" VALUES (9780261102361, 'The Lord of The Rings: The Two Towers', 'Fantasy', 2007, 10.99, 464, 'HarperCollins Publishers');
INSERT INTO "book" VALUES (9780261102378, 'The Lord of The Rings: The Return Of The King', 'Fantasy', 2007, 10.99, 464, 'HarperCollins Publishers');
INSERT INTO "book" VALUES (9780786838653, 'Percy Jackson And The Olympians: The Lightning Thief', 'Fantasy', 2006, 8.99, 416, 'Disney-Hyperion');
INSERT INTO "book" VALUES (9781423103349, 'Percy Jackson And The Olympians: The Sea Of Monsters', 'Fantasy', 2007, 8.99, 320, 'Disney-Hyperion');
INSERT INTO "book" VALUES (9781423101482, 'Percy Jackson And The Olympians: The Titans Curse', 'Fantasy', 2008, 8.99, 352, 'Disney-Hyperion');
INSERT INTO "book" VALUES (9781423101499, 'Percy Jackson And The Olympians: The Battle of The Labyrinth', 'Fantasy', 2009, 8.99, 400, 'Disney-Hyperion');
INSERT INTO "book" VALUES (9781423101505, 'Percy Jackson And The Olympians: The Last Olympian', 'Fantasy', 2011, 8.99, 432, 'Disney-Hyperion');
INSERT INTO "book" VALUES (9780545075527, 'You Are My Sunshine', 'Children', 2011, 7.99, 12, 'Scholastic Inc');
INSERT INTO "book" VALUES (9780545688864, 'I am a big brother', 'Children', 2015, 7.99, 24, 'Scholastic Inc');
INSERT INTO "book" VALUES (9780671493172, 'A to Z', 'Children', 1984, 6.99, 8, 'Little Simon');
INSERT INTO "book" VALUES (9780545518062, 'Twinkle Twinkle Little Star', 'Children', 2014, 7.99, 12, 'Scholastic Inc');
INSERT INTO "book" VALUES (9780008267124, 'Why I love my brother', 'Children', 2018, 12.99, 30, 'HarperCollins Publishers');
INSERT INTO "book" VALUES (9781459805798, 'Honeycomb', 'Teen', 2014, 9.95, 152, 'Ocra Book Publishers');
INSERT INTO "book" VALUES (9780062918055, 'The Upside of Halling', 'Teen', 2020, 16.49, 288, 'HarperCollins Publishers');
COMMIT;

-- ----------------------------
-- Table structure for checkout_basket
-- ----------------------------
DROP TABLE IF EXISTS "checkout_basket";
CREATE TABLE "checkout_basket" (
  "checkout_id" numeric(4) NOT NULL,
  "isbn" numeric(13),
  "quantity" numeric(3)
)
;

-- ----------------------------
-- Records of checkout_basket
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for customer
-- ----------------------------
DROP TABLE IF EXISTS "customer";
CREATE TABLE "customer" (
  "email" varchar(40) COLLATE "pg_catalog"."default" NOT NULL,
  "name" varchar(20) COLLATE "pg_catalog"."default",
  "address" varchar(50) COLLATE "pg_catalog"."default",
  "phone_num" numeric(10),
  "password" varchar(20) COLLATE "pg_catalog"."default",
  "checkout_id" numeric(4)
)
;

-- ----------------------------
-- Records of customer
-- ----------------------------
BEGIN;
INSERT INTO "customer" VALUES ('sum@gmail.com', 'sum', 'New York Red Light Road', 4169235654, 'sum123456', NULL);
INSERT INTO "customer" VALUES ('root@gmail.com', 'root', 'No.5 Longqiao Road', 4165343412, 'root345', NULL);
INSERT INTO "customer" VALUES ('jb@gmail.com', 'bj', 'No.10 Siege Road', 7058392234, 'jb213', NULL);
COMMIT;

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS "orders";
CREATE TABLE "orders" (
  "order_num" numeric(4) NOT NULL,
  "shipping_info" varchar(70) COLLATE "pg_catalog"."default",
  "billing_info" varchar(70) COLLATE "pg_catalog"."default",
  "total_price" numeric(6,2),
  "email" varchar(40) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of orders
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for publisher
-- ----------------------------
DROP TABLE IF EXISTS "publisher";
CREATE TABLE "publisher" (
  "p_name" varchar(40) COLLATE "pg_catalog"."default" NOT NULL,
  "address" varchar(50) COLLATE "pg_catalog"."default",
  "phone_num" numeric(10),
  "email" varchar(40) COLLATE "pg_catalog"."default",
  "bank_account" numeric(8,2)
)
;

-- ----------------------------
-- Records of publisher
-- ----------------------------
BEGIN;
INSERT INTO "publisher" VALUES ('Disney-Hyperion', '42 Disney dr', 7983102930, 'disney_hyperion@gmail.com', 0.00);
INSERT INTO "publisher" VALUES ('HarperCollins Publishers', '33 Harper st', 7053224478, 'harper_collins@gmail.com', 0.00);
INSERT INTO "publisher" VALUES ('Scholastic Inc', '34 Fourth st', 4162783493, 'scholastic_inc@gmail.com', 0.00);
INSERT INTO "publisher" VALUES ('Little Simon', '34 Fake st', 4162712312, 'little_simon@gmail.com', 0.00);
INSERT INTO "publisher" VALUES ('Ocra Book Publishers', '123 Fake st', 4162710821, 'orca_book@gmail.com', 0.00);
COMMIT;

-- ----------------------------
-- Table structure for storage
-- ----------------------------
DROP TABLE IF EXISTS "storage";
CREATE TABLE "storage" (
  "warehouse_id" numeric(2) NOT NULL,
  "isbn" numeric(13) NOT NULL,
  "quantity" numeric(3)
)
;

-- ----------------------------
-- Records of storage
-- ----------------------------
BEGIN;
INSERT INTO "storage" VALUES (4, 9780545075527, 12);
INSERT INTO "storage" VALUES (4, 9780545688864, 67);
INSERT INTO "storage" VALUES (4, 9780671493172, 54);
INSERT INTO "storage" VALUES (4, 9780545518062, 36);
INSERT INTO "storage" VALUES (4, 9780008267124, 98);
INSERT INTO "storage" VALUES (4, 9781459805798, 29);
INSERT INTO "storage" VALUES (4, 9780062918055, 25);
INSERT INTO "storage" VALUES (4, 9780261102354, 30);
INSERT INTO "storage" VALUES (4, 9780261102361, 23);
INSERT INTO "storage" VALUES (4, 9780261102378, 37);
INSERT INTO "storage" VALUES (4, 9780261102217, 40);
INSERT INTO "storage" VALUES (4, 9780786838653, 15);
INSERT INTO "storage" VALUES (4, 9781423103349, 12);
INSERT INTO "storage" VALUES (4, 9781423101482, 19);
INSERT INTO "storage" VALUES (4, 9781423101499, 21);
INSERT INTO "storage" VALUES (4, 9781423101505, 29);

COMMIT;

-- ----------------------------
-- Table structure for track
-- ----------------------------
DROP TABLE IF EXISTS "track";
CREATE TABLE "track" (
  "order_num" numeric(4) NOT NULL,
  "warehouse_id" numeric(2) NOT NULL,
  "location" varchar(50) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of track
-- ----------------------------
BEGIN;
COMMIT;

-- ----------------------------
-- Table structure for warehouse
-- ----------------------------
DROP TABLE IF EXISTS "warehouse";
CREATE TABLE "warehouse" (
  "warehouse_id" numeric(2) NOT NULL,
  "address" varchar(50) COLLATE "pg_catalog"."default",
  "phone_num" numeric(10)
)
;

-- ----------------------------
-- Records of warehouse
-- ----------------------------
BEGIN;
INSERT INTO "warehouse" VALUES (4, '53 Centre dr K0A1V0 Ottawa Ontario', 4166134532);
COMMIT;

-- ----------------------------
-- Table structure for written_by
-- ----------------------------
DROP TABLE IF EXISTS "written_by";
CREATE TABLE "written_by" (
  "isbn" numeric(13) NOT NULL,
  "a_name" varchar(40) COLLATE "pg_catalog"."default" NOT NULL
)
;

-- ----------------------------
-- Records of written_by
-- ----------------------------
BEGIN;
INSERT INTO "written_by" VALUES (9780545518062, 'Caroline Jayne Church');
INSERT INTO "written_by" VALUES (9780008267124, 'Daniel Howarth');
INSERT INTO "written_by" VALUES (9781459805798, 'Patricia Mccowen');
INSERT INTO "written_by" VALUES (9780062918055, 'Alex Light');
INSERT INTO "written_by" VALUES (9780786838653, 'Rick Riordan');
INSERT INTO "written_by" VALUES (9781423103349, 'Rick Riordan');
INSERT INTO "written_by" VALUES (9781423101482, 'Rick Riordan');
INSERT INTO "written_by" VALUES (9781423101499, 'Rick Riordan');
INSERT INTO "written_by" VALUES (9781423101505, 'Rick Riordan');
INSERT INTO "written_by" VALUES (9780261102217, 'J.R.R. Tolkien');
INSERT INTO "written_by" VALUES (9780261102354, 'J.R.R. Tolkien');
INSERT INTO "written_by" VALUES (9780261102361, 'J.R.R. Tolkien');
INSERT INTO "written_by" VALUES (9780261102378, 'J.R.R. Tolkien');
INSERT INTO "written_by" VALUES (9780545075527, 'Jimmie Davis');
INSERT INTO "written_by" VALUES (9780545688864, 'Caroline Jayne Church');
INSERT INTO "written_by" VALUES (9780671493172, 'Caroline Jayne Church');
COMMIT;

-- ----------------------------
-- Primary Key structure for table author
-- ----------------------------
ALTER TABLE "author" ADD CONSTRAINT "author_pkey" PRIMARY KEY ("a_name");

-- ----------------------------
-- Primary Key structure for table book
-- ----------------------------
ALTER TABLE "book" ADD CONSTRAINT "book_pkey" PRIMARY KEY ("isbn");

-- ----------------------------
-- Primary Key structure for table checkout_basket
-- ----------------------------
ALTER TABLE "checkout_basket" ADD CONSTRAINT "checkout_basket_pkey" PRIMARY KEY ("checkout_id");

-- ----------------------------
-- Primary Key structure for table customer
-- ----------------------------
ALTER TABLE "customer" ADD CONSTRAINT "customer_pkey" PRIMARY KEY ("email");

-- ----------------------------
-- Primary Key structure for table orders
-- ----------------------------
ALTER TABLE "orders" ADD CONSTRAINT "orders_pkey" PRIMARY KEY ("order_num");

-- ----------------------------
-- Primary Key structure for table publisher
-- ----------------------------
ALTER TABLE "publisher" ADD CONSTRAINT "publisher_pkey" PRIMARY KEY ("p_name");

-- ----------------------------
-- Primary Key structure for table storage
-- ----------------------------
ALTER TABLE "storage" ADD CONSTRAINT "storage_pkey" PRIMARY KEY ("warehouse_id", "isbn");

-- ----------------------------
-- Primary Key structure for table track
-- ----------------------------
ALTER TABLE "track" ADD CONSTRAINT "track_pkey" PRIMARY KEY ("order_num", "warehouse_id");

-- ----------------------------
-- Primary Key structure for table warehouse
-- ----------------------------
ALTER TABLE "warehouse" ADD CONSTRAINT "warehouse_pkey" PRIMARY KEY ("warehouse_id");

-- ----------------------------
-- Primary Key structure for table written_by
-- ----------------------------
ALTER TABLE "written_by" ADD CONSTRAINT "written_by_pkey" PRIMARY KEY ("isbn", "a_name");

-- ----------------------------
-- Foreign Keys structure for table book
-- ----------------------------
ALTER TABLE "book" ADD CONSTRAINT "book_p_name_fkey" FOREIGN KEY ("p_name") REFERENCES "publisher" ("p_name") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table checkout_basket
-- ----------------------------
ALTER TABLE "checkout_basket" ADD CONSTRAINT "checkout_basket_isbn_fkey" FOREIGN KEY ("isbn") REFERENCES "book" ("isbn") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table customer
-- ----------------------------
ALTER TABLE "customer" ADD CONSTRAINT "customer_checkout_id_fkey" FOREIGN KEY ("checkout_id") REFERENCES "checkout_basket" ("checkout_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table orders
-- ----------------------------
ALTER TABLE "orders" ADD CONSTRAINT "orders_email_fkey" FOREIGN KEY ("email") REFERENCES "customer" ("email") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table storage
-- ----------------------------
ALTER TABLE "storage" ADD CONSTRAINT "storage_isbn_fkey" FOREIGN KEY ("isbn") REFERENCES "book" ("isbn") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "storage" ADD CONSTRAINT "storage_warehouse_id_fkey" FOREIGN KEY ("warehouse_id") REFERENCES "warehouse" ("warehouse_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table track
-- ----------------------------
ALTER TABLE "track" ADD CONSTRAINT "track_order_num_fkey" FOREIGN KEY ("order_num") REFERENCES "orders" ("order_num") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "track" ADD CONSTRAINT "track_warehouse_id_fkey" FOREIGN KEY ("warehouse_id") REFERENCES "warehouse" ("warehouse_id") ON DELETE NO ACTION ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table written_by
-- ----------------------------
ALTER TABLE "written_by" ADD CONSTRAINT "written_by_a_name_fkey" FOREIGN KEY ("a_name") REFERENCES "author" ("a_name") ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE "written_by" ADD CONSTRAINT "written_by_isbn_fkey" FOREIGN KEY ("isbn") REFERENCES "book" ("isbn") ON DELETE NO ACTION ON UPDATE NO ACTION;
